package com.php.Agent;

import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.php.Base.BaseClassCustomer;

public class AgentLinks extends BaseClassCustomer{
	WebDriver driver;
	
	@FindBy(xpath="//a[@class='active_hotels waves-effect']")
	private WebElement hotel;
	
	@FindBy(xpath="//a[@class='active_flights waves-effect']")
	private WebElement flight;
	
	
	@FindBy(xpath="//a[@class='active_tours waves-effect']")
	private WebElement tours;
	
	@FindBy(xpath="//a[@class='active_visa waves-effect']")
	private WebElement visa;
	
	@FindBy(xpath="//a[@class='active_blog waves-effect']")
	private WebElement blog;
	
	@FindBy(xpath="//a[@class='active_offers waves-effect']")
	private WebElement offers;
	
	@FindBy(xpath="//span[@id='select2-hotels_city-container' and @title=' Search by City']")
	private WebElement search;
	
	@FindBy(xpath="//input[@role='searchbox'][1]")
	private WebElement entercity;
	
	@FindBy(css=".select2-results__options")
	List <WebElement> options;
	
	@FindBy(xpath="//button[@type='submit']")
	private WebElement submitbutton;
	
	
	
	 public AgentLinks(WebDriver driver) {
			// TODO Auto-generated constructor stub
		
			this.driver=driver;
			PageFactory.initElements(driver,this);
			}
	 public void clickHotel() throws InterruptedException
	 {
		 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;  
			jsExecutor.executeScript("arguments[0].style.border='2px solid red'",hotel);
		 hotel.click();
		 Thread.sleep(4000);
		 search.click();
		 
		 
	 }
	 public void Entercity(Object cityname) throws InterruptedException
		{
			entercity.sendKeys(cityname.toString() );
			 Thread.sleep(3000);
			 
		}
	 public void selectOptions()
	 {
		 for(WebElement option :options)
		 {
			 if(option.getText().equalsIgnoreCase("Singapore,Singapore"))
			 {
				 option.click();
				 break;
			 }
			 
		 }
	 }
	 public void clickSearchButton() throws InterruptedException
	 {
		 submitbutton.click();
		 Thread.sleep(4000);
		 JavascriptExecutor js = (JavascriptExecutor) driver;
		 js.executeScript("window.scrollBy(0,450)", "");
	 }
	 
	 
	 public void clickFlights() throws InterruptedException
	 {
		 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;  
			jsExecutor.executeScript("arguments[0].style.border='2px solid red'",flight);
		 flight.click();
		 Thread.sleep(4000);
		 JavascriptExecutor js = (JavascriptExecutor) driver;
		 js.executeScript("window.scrollBy(0,450)", "");
	 }
	 
	 public void clickTours() throws InterruptedException
	 { 
		 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;  
			jsExecutor.executeScript("arguments[0].style.border='2px solid red'",tours);
		 tours.click();
		 Thread.sleep(4000);
		 JavascriptExecutor js = (JavascriptExecutor) driver;
		 js.executeScript("window.scrollBy(0,450)", "");
	 } 
		 
	 public void clickVisa() throws InterruptedException
	 {
		 
		 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;  
			jsExecutor.executeScript("arguments[0].style.border='2px solid red'",visa);
		 visa.click();
		 Thread.sleep(4000);
		 JavascriptExecutor js = (JavascriptExecutor) driver;
		 js.executeScript("window.scrollBy(0,450)", "");
	 } 
	 public void clickBlog() throws InterruptedException
	 {
		 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;  
			jsExecutor.executeScript("arguments[0].style.border='2px solid red'",blog);
		 blog.click();
		 Thread.sleep(4000);
		 JavascriptExecutor js = (JavascriptExecutor) driver;
		 js.executeScript("window.scrollBy(0,450)", "");
	 } 
	 public void clickOffers() throws InterruptedException
	 {
		 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;  
			jsExecutor.executeScript("arguments[0].style.border='2px solid red'",offers); 
		 offers.click();
		 Thread.sleep(4000);
		 JavascriptExecutor js = (JavascriptExecutor) driver;
		 js.executeScript("window.scrollBy(0,450)", "");
		 
	 } 
	 
	 
}


