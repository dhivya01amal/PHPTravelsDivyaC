package com.php.Agent;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.php.Base.BaseClassCustomer;

public class AgentLogin extends BaseClassCustomer{
	WebDriver driver;

	@FindBy(xpath="//input[@name='email']")
	private WebElement Email;

	@FindBy(xpath="//input[@name='password']")
	private WebElement Password;

	@FindBy(xpath="//button[@type='submit']")
	private WebElement LoginButton;


		 public AgentLogin(WebDriver driver) {
			// TODO Auto-generated constructor stub
		
			this.driver=driver;
			PageFactory.initElements(driver,this);
			}
		 
		public void EnterEmail(Object agentEmail) throws InterruptedException
		{
			Email.sendKeys(agentEmail.toString() );
			
		}
		
		public void EnterPassword(Object agentPassword) throws InterruptedException
		{
			Password.sendKeys(  agentPassword.toString() );
			
		}
		public void ClearInvalidEmail(Object AdminEmail) throws InterruptedException
		{
			Email.clear();
			Thread.sleep(2000);
			Password.clear();
			Thread.sleep(2000);
			
		}
		
		public void ClickLogin() throws InterruptedException
		{
			
			LoginButton.click();
			Thread.sleep(4000);
		}

}


