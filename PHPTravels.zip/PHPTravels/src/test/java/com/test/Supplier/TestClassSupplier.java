package com.test.Supplier;

import java.io.IOException;
import java.util.Iterator;
import java.util.Set;

import org.testng.Assert;
import org.testng.annotations.Ignore;
import org.testng.annotations.Test;

import com.php.Base.BaseClassSupplier;
import com.php.Customer.CustomerLogin;
import com.php.Supplier.SupplierDashboard;
import com.php.Supplier.SupplierLogin;
import com.php.utilities.ExcelUtility;

public class TestClassSupplier extends BaseClassSupplier{
	SupplierLogin supobj;
	SupplierDashboard sprdobj;

	
@Test(priority = 1,description="Login to the Supplier Dashboard page with invalid email and valid password")
	
	public void LogininToDashboardwithInvalidEmail() throws IOException, InterruptedException {
		
		supobj=new SupplierLogin(driver);
		
Object SupplierEmail=ExcelUtility.GetCellData(1, 3,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelHome.xlsx", 0);
		
		Object SupplierPassword=ExcelUtility.GetCellData(1,2,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelHome.xlsx", 0);
	
		supobj.EnterEmail(SupplierEmail);
		Thread.sleep(2000);
		supobj.EnterPassword(SupplierPassword);
		supobj.ClickLogin();
		Thread.sleep(3000);
		supobj.ClearInvalidEmail(SupplierEmail);
		supobj.ClearInvalidEmail(SupplierPassword);
		
		
}
@Test(priority = 2 ,description="Login to the Supplier Dashboard page with valid email and password")
	
	public void LogininToDashboard() throws IOException, InterruptedException {
		
		supobj=new SupplierLogin(driver);
		
Object SupplierEmail=ExcelUtility.GetCellData(4, 1,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelHome.xlsx", 0);
		
		Object SupplierPassword=ExcelUtility.GetCellData(4,2,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelHome.xlsx", 0);
	
		supobj.EnterEmail(SupplierEmail);
	supobj.EnterPassword(SupplierPassword);
		supobj.ClickLogin();
		Thread.sleep(7000);
}
@Test(priority = 3 ,description="Check whether the text Sales overview and summary is present or not ")
public void CheckTextIsPresentOrNot() throws InterruptedException
{
	sprdobj=new SupplierDashboard(driver);	
	String txt=sprdobj.CheckTextIsPresentOrNot();
	Assert.assertEquals(txt,"Sales overview & summary");

}
@Test(priority = 4 ,description="Check whether Revenue and break dwon details are present or not ")
public void ChecRevenueDetailIsPresentOrNot() throws InterruptedException
{
	sprdobj=new SupplierDashboard(driver);	
	String txt1=sprdobj.CheckRevenueBreakdownIsPresentOrNot();
	Assert.assertEquals(txt1,"Revenue Breakdown 2023");
	Thread.sleep(2000);

}
@Ignore
@Test(priority = 5,description="Verify the links my bookings and change the booking status from pending to confirmed. ")
public void VerifyMyBookings() throws InterruptedException
{
	sprdobj=new SupplierDashboard(driver);	
	sprdobj.ClickBookings();
	Thread.sleep(2000);
	Set<String> wnd1 = driver.getWindowHandles();
	
	//window handles iteration
	Iterator<String> i1 = wnd1.iterator();
	String prntw1 = i1.next();
	String popwnd1 = i1.next();
	//switching pop up window handle id
	driver.switchTo().window(popwnd1);
	driver.close();
	driver.switchTo().window(prntw1);
	Thread.sleep(2000);
	
	
	Thread.sleep(5000);
}
@Test(priority = 6,description="Verify the Tours Module ")
public void verifyTourModule() throws InterruptedException

	{
		sprdobj=new SupplierDashboard(driver);
		sprdobj.clickToursModule();
		Thread.sleep(2000);
		sprdobj.clickLogout();
		Thread.sleep(2000);
		}

}



